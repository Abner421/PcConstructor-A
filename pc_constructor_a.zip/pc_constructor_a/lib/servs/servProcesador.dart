import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:pc_constructor_a/model/modeloProcesador.dart';