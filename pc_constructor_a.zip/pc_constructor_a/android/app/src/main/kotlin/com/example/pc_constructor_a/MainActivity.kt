package com.example.pc_constructor_a

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
